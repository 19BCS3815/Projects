package com.seno;

public class SearchBean {
	
    private String fromDes;
    private String toDes;
    private String Date;
    //private String lastName;
    //public boolean valid;
	
	
    //public String getFirstName() {
     //  return firstName;
	//}

    //public void setFirstName(String newFirstName) {
     //  firstName = newFirstName;
	//}

	
    //public String getLastName() {
      // return lastName;
		//	}

   // public void setLastName(String newLastName) {
     //  lastName = newLastName;
		//	}
			

    public String getfromdes() {
       return fromDes;
	}

    public void setfromDes(String fromdes) {
      fromDes=fromdes;
	}
    public String getdate() {
        return fromDes;
 	}

     public void setdate(String date) {
       Date=date;
 	}
     
    
	
			
    public String gettomDes() {
       return toDes;
			}

    public void settodes(String todes) {
       toDes = todes;
			}

}
